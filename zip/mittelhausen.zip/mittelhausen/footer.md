---
Title: Footer
Status: shared
---
<center><small>[Made with &hearts; and Datenstrom](https://datenstrom.se/yellow/)</small></center>